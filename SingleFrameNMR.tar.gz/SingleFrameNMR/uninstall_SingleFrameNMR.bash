
cd ..
rmdir -p SingleFrameNMR