
// Gordon Chalmers

//	pdb_file=argv[1];
//	topology_file=argv[2];
//	out_directory=argv[3];
//	Karplus=argv[4];
//      Karplus_coefficents=argv[5];
//      max_distance=argv[6];

#define GNUPLOT "gnuplot -persist"
#include <string>
#include <cstdlib>
#include <vector> 
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream> 
#include <sstream> 
using std::ios;
using namespace std;
#include <cstring>  
#include <math.h>
#include <time.h>
#include "glylib.h"


double string_to_double(const std::string& s)
{
	std::istringstream i(s);
	double x;
	if (!(i >> x))
	return 0;
	return x;
}

int string_to_int(const std::string& s)
{
	std::istringstream i(s);
	int x;
	if (!(i >> x))
	return 0;
	return x;
}

string int_to_string(int n)
{
	ostringstream strm;
	strm << n;
	return strm.str ();
}


double xcoordinate12=0;
double ycoordinate12=0; 
double zcoordinate12=0;  
double xcoordinate34=0; 
double ycoordinate34=0; 
double zcoordinate34=0;     
double xcoordinate=0; 
double ycoordinate=0; 
double zcoordinate=0;
double xcross=0; 
double ycross=0; 
double zcross=0; 
double ina=0; 
double angle=0; 
double angle_of_atom=0; 
double angle_in_degrees=0;  
string text;	
double dot_product=0;
int natom=0;
double x[3];
double y[3];
double z[3];

int total_coupling=0;
string temp_curve;

int atom_four[4];
string atom_type_four[4]={};

int found_space[7];
double coupling_3J=0;

int adjacent_atom1[10000];
int adjacent_atom2[10000];
int adjacent_atoms_total=0;

int i1=0;
int i2=0;
int i3=0;
int i4=0;

int total_curves=1000; 
string *curve=new string[total_curves];
string *curve_atom1=new string[total_curves];
string *curve_atom2=new string[total_curves];
string *curve_atom3=new string[total_curves];
string *curve_atom4=new string[total_curves];
double *coefficient1=new double[total_curves];
double *coefficient2=new double[total_curves];
double *coefficient3=new double[total_curves];

string Karplus;
char * Karplus_coefficients;


void curve_information(char * Karplus_coefficients){
	
// get all information from Karplus coefficients file	
	
	string text1; 
	string text2;
	string text3; 
	string text4; 
	string text5; 
	string text6; 
	string text7; 
	string type;
	
	ifstream kc(Karplus_coefficients);
	
	if(kc.good()==0){
		cout << "No file of equation coefficients is found." << endl;
		exit(1);
	}

	total_curves=0;
	
	while(getline(kc,text)){
		
		found_space[0]=text.find(" ");		
		for(int i0=1; i0<7; i0++){
			found_space[i0]=(size_t) text.find(" ",found_space[i0-1]+1);	
		}

		type=text.substr((size_t) 0,(size_t) found_space[0]);
		text1=text.substr((size_t) found_space[0]+1,(size_t) found_space[1]-found_space[0]-1);
		text2=text.substr((size_t) found_space[1]+1,(size_t) found_space[2]-found_space[1]-1);
		text3=text.substr((size_t) found_space[2]+1,(size_t) found_space[3]-found_space[2]-1);
		text4=text.substr((size_t) found_space[3]+1,(size_t) found_space[4]-found_space[3]-1);
		text5=text.substr((size_t) found_space[4]+1,(size_t) found_space[5]-found_space[4]-1);
		text6=text.substr((size_t) found_space[5]+1,(size_t) found_space[6]-found_space[5]-1);
		text7=text.substr((size_t) found_space[6]+1);

		curve[total_curves]=type;
		
		if(curve[total_curves]!=""){
			
//			cout << curve[total_curves] << endl;
			
			curve_atom1[total_curves]=text1.substr(0,1);
			curve_atom2[total_curves]=text2.substr(0,1);
			curve_atom3[total_curves]=text3.substr(0,1);
			curve_atom4[total_curves]=text4.substr(0,1);
			
			coefficient1[total_curves]=string_to_double(text5); 
			coefficient2[total_curves]=string_to_double(text6); 
			coefficient3[total_curves]=string_to_double(text7); 		
			
//			cout << total_curves << " " << curve_atom1[total_curves] << " " << curve_atom2[total_curves] << " " << curve_atom3[total_curves] << " " << curve_atom4[total_curves] << endl;
//			cout << coefficient1[total_curves] << " " << coefficient2[total_curves] << " " << coefficient3[total_curves] << endl << endl;		
			text1.clear(); text2.clear(); text3.clear(); text4.clear(); text5.clear(); text6.clear(); text7.clear();
			
			total_curves++;		
		}
	}
	kc.close();
	
}



double angle_degrees(double *atom_x, double *atom_y, double *atom_z, int atom_four[3]){ 

// function calculates angle in degrees from -180 to 180

	for(int i=0; i<4; i++){
		x[i]=atom_x[atom_four[i]]; y[i]=atom_y[atom_four[i]]; z[i]=atom_z[atom_four[i]];
	}

	xcoordinate12=(y[1]-y[2])*(z[2]-z[3])-(z[1]-z[2])*(y[2]-y[3]);
	ycoordinate12=(z[1]-z[2])*(x[2]-x[3])-(x[1]-x[2])*(z[2]-z[3]);
	zcoordinate12=(x[1]-x[2])*(y[2]-y[3])-(y[1]-y[2])*(x[2]-x[3]);

	xcoordinate34=(y[3]-y[4])*(z[2]-z[3])-(z[3]-z[4])*(y[2]-y[3]);
	ycoordinate34=(z[3]-z[4])*(x[2]-x[3])-(x[3]-x[4])*(z[2]-z[3]);
	zcoordinate34=(x[3]-x[4])*(y[2]-y[3])-(y[3]-y[4])*(x[2]-x[3]);

	ina = -(xcoordinate12*xcoordinate34+ycoordinate12*ycoordinate34+zcoordinate12*zcoordinate34);  
	ina = (double) ina / sqrt(xcoordinate12*xcoordinate12+ycoordinate12*ycoordinate12+zcoordinate12*zcoordinate12); 
	ina = (double) ina / sqrt(xcoordinate34*xcoordinate34+ycoordinate34*ycoordinate34+zcoordinate34*zcoordinate34);  	 

	xcoordinate=xcoordinate34-xcoordinate12;
	ycoordinate=ycoordinate34-ycoordinate12;
	zcoordinate=zcoordinate34-zcoordinate12;

	xcross=ycoordinate12*zcoordinate34-zcoordinate12*ycoordinate34;
	ycross=zcoordinate12*xcoordinate34-xcoordinate12*zcoordinate34;
	zcross=xcoordinate12*ycoordinate34-ycoordinate12*xcoordinate34;
	
	angle_of_atom=acos(ina);  
	dot_product=xcoordinate*xcross+ycoordinate*ycross+zcoordinate*zcross;

	if(dot_product<0){angle_of_atom=-angle_of_atom;}
	angle_in_degrees=(double) angle_of_atom*180/3.14159265;
	return angle_in_degrees;
	
}



double spin_coupling(string *atom_type_four, double angle, string file, int temp_total_coupling){    

// function calculates Karplus coupling from curve information
	
	for(int i=temp_total_coupling; i<total_curves; i++){
		temp_curve=curve[i];
		if(temp_curve.compare(file)==0||temp_curve.substr(0,7).compare(file)==0){ 
			if(curve_atom1[i].compare(atom_type_four[0])==0){
				if(curve_atom2[i].compare(atom_type_four[1])==0){
					if(curve_atom3[i].compare(atom_type_four[2])==0){
						if(curve_atom4[i].compare(atom_type_four[3])==0){
							total_coupling=i+1;
							return coefficient1[i]*cos(angle)*cos(angle)+coefficient2[i]*cos(angle)+coefficient3[i];
						}
					}			
				}
			}
		}
	}
	
// if coefficients are not in file

	total_coupling=-1;	
	return 0;
}


int main(int argc, char *argv[]) { /* standard main function */


	// topology file 

	int mi,ri,ai,bi; 	

	/* These are GLYLIB types */
	/*fileset OF;*/

	fileset IF; 

	assembly A; 		
	molindex moli;		
	molecule *mtmp;		
	residue *rtmp;		
	atom *atmp, *a2tmp; 	
	
	IF.N = strdup(argv[2]); 	
	
	A = load_amber_prmtop(IF); 	
	
	string * atomName=new string[10000];
	string * atomType=new string[10000];
	int *atomNumber=new int[10000];
	string * atomResidue=new string[10000];
	string * residue=new string[10000];

	// initialize
	
	for(int i=0; i<4; i++){
		atom_four[i]=0;
	}

	// natom is # of atoms
	
	natom = 0;
	adjacent_atoms_total=0;
	
	if (A.nm < 1){ mywhine("No molecules found in prmtop file!"); }

	for (mi = 0; mi < A.nm; mi++){ 
		mtmp = &A.m[mi][0]; 
		for (ri = 0; ri < mtmp[0].nr; ri++){ 
			rtmp = &mtmp[0].r[ri]; 
			
			for (ai = 0; ai < rtmp[0].na; ai++){
				atmp = &rtmp[0].a[ai];
				residue[natom] = int_to_string(rtmp[0].n);
				//residue[natom]=ri;
				atomName[natom] = (atmp[0]).N;
				atomType[natom] = (atmp[0]).T[0];
				atomNumber[natom] = (atmp[0]).n;
				atomResidue[natom] = A.m[atmp[0].moli.m][0].r[atmp[0].moli.r].N;
				natom++;

				for(bi=0;bi<atmp[0].nmb;bi++){ 
					moli=atmp[0].mb[bi].t; 
					a2tmp=&A.m[moli.m][0].r[moli.r].a[moli.a]; 

					i1=(atmp[0]).n;  
					i2=(a2tmp[0]).n;
					
					//adjacent[i1-1][i2-1]=2
					adjacent_atom1[adjacent_atoms_total]=i1-1;
					adjacent_atom2[adjacent_atoms_total]=i2-1;
					adjacent_atoms_total++;
				} 
			}
		}		
	}
	
	
// inputs 
	
	double max_distance=string_to_double(argv[6]);
//	char * Karplus_coefficients=argv[5];
	string Karplus=argv[4];
	string out_directory=argv[3];
	string pdb_file=argv[1];
	string topology_file=argv[2];
	
// pdb file - atom numbers and coordinates
	
	int total_atoms=0;
	
	int *atom_number=new int[natom];
	double *atom_x=new double[natom];
	double *atom_y=new double[natom];
	double *atom_z=new double[natom];
	string *atom_type=new string[natom];
	
	for(int i=0; i<natom; i++){
		atom_number[i]=0;
	}	
	
	ifstream pf(argv[1]);
	pf.seekg(0);
	
	//	total_curves=string_to_int(text);
	
// coordinates from atoms 	
	
	while(getline(pf,text)){
		if(text.substr(0,4).compare("ATOM")==0||text.substr(0,6).compare("HETATOM")==0){
			atom_number[total_atoms]=string_to_int(text.substr(6,5))-1;
			atom_x[total_atoms]=string_to_double(text.substr(30,8));
			atom_y[total_atoms]=string_to_double(text.substr(38,8));
			atom_z[total_atoms]=string_to_double(text.substr(46,8));
			atom_type[total_atoms]=atomType[atom_number[total_atoms]];
			total_atoms++;					
		}
	}
	pf.close();

	cout << "topology file has " << natom << " atoms." << endl;
	cout << "pdb file has " << total_atoms << " atoms." << endl;
	
	if(total_atoms!=natom){ 
		cout << "The number of atoms in topology file does not agree with the pdb file." << endl << endl;
		exit(0);
	}

// curve information 

	curve_information(argv[5]);
	

// output files - .txt and .csv

	string coupling_output=out_directory;
	coupling_output.append("/3J_coupling_output_");
	coupling_output.append(pdb_file);
	coupling_output.append(".txt");
	
	char *couplingoutput=new char [coupling_output.length()+1];
	strcpy(couplingoutput, coupling_output.c_str());

	ofstream co(couplingoutput);
	
	
	string coupling_output_excel=out_directory;
	coupling_output_excel.append("/3J_coupling_output_");
	coupling_output_excel.append(pdb_file);
	coupling_output_excel.append(".csv");

	char *couplingoutputexcel=new char [coupling_output_excel.length()+1];
	strcpy(couplingoutputexcel, coupling_output_excel.c_str());

	ofstream coe;
	coe.open(couplingoutputexcel);

	
	coe << "3J coupling output " << endl << endl;
	coe << "input and output files are : " << endl;
	coe << argv[1] << " " << argv[2] << endl;
	coe << coupling_output_excel << endl << endl;
	coe << "text file is also included in output - separate file" << endl << endl;
	
	time_t rawtime;
	time (&rawtime);

	coe << "time of creation " << ctime (&rawtime) << endl;
	coe << "check reference document." << endl << endl << endl;
	coe << "curve type,atom No.1,atom No.2,atom No.3,atom No.4,type 1,type 2,type 3,type 4,3-bond,angle,coupling" << endl << endl; 
	
	
	co << "3J coupling output." << endl << endl;
	co << "input and output files are : " << endl;
	co << argv[1] << " " << argv[2] << endl;
	co << coupling_output << endl << endl;
	co << "note : there is a .csv file in the directory of the program output.  this is a -separate file-." << endl << endl;
	co << "output : curve type, atom numbers, and atom type" << endl;
	co << "       : 3-bond, angle, and coupling." << endl << endl;
	time (&rawtime);
	co << "time of creation " << ctime (&rawtime) << endl << endl;
	
	
	// all 3J couplings of adjacen

	for(int total1=0; total1<adjacent_atoms_total; total1++){
		for(int total2=0; total2<adjacent_atoms_total; total2++){
			for(int total3=0; total3<adjacent_atoms_total; total3++){

				i1=adjacent_atom1[total1];
				i2=adjacent_atom2[total1];
				i3=adjacent_atom1[total3];
				i4=adjacent_atom2[total3];			
				
				if(adjacent_atom1[total2]==i2){ 
					if(adjacent_atom2[total2]==i3){

						if(adjacent_atom1[total1]!=adjacent_atom1[total3]){
							if(adjacent_atom1[total1]!=adjacent_atom2[total3]){
								if(adjacent_atom1[total1]!=adjacent_atom2[total2]){
									if(adjacent_atom2[total1]!=adjacent_atom2[total3]){
										
										atom_four[0]=i1; atom_type_four[0]=atom_type[i1];
										atom_four[1]=i2; atom_type_four[1]=atom_type[i2];
										atom_four[2]=i3; atom_type_four[2]=atom_type[i3];
										atom_four[3]=i4; atom_type_four[3]=atom_type[i4];

										// angle
										
										angle=angle_degrees(atom_x, atom_y, atom_z, atom_four);

						
									
						
										total_coupling=0;										
										
										while(total_coupling>-1){
											
											// coupling
											
											coupling_3J=spin_coupling(atom_type_four, angle, Karplus,total_coupling);
											
											if(i4>i1){

												if(coupling_3J>0){ 

													co << temp_curve << " " << i1 << " " << i2 << " " << i3 << " " << i4 << " : " << atomType[i1] << "-" << atomType[i2] << "-" << atomType[i3] << "-" << atomType[i4] << endl; 
													co << atomResidue[i1] << ":" << residue[i1] << ":" << atomName[i1] << "-" << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << "-" << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << "-" << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << "  " << angle << " " << coupling_3J << endl << endl;

													coe << temp_curve << "," << i1 << "," << i2 << "," << i3 << "," << i4 << "," << atomType[i1] << "," << atomType[i2] << "," << atomType[i3] << "," << atomType[i4] << "," << atomResidue[i1] << ":" << residue[i1] << ":" << atomName[i1] << "-" << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << "-" << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << "-" << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << "," << angle << "," << coupling_3J << endl << endl;

//													cout << temp_curve << " " << i1 << " " << i2 << " " << i3 << " " << i4 << " : " << atomType[i1] << "-" << atomType[i2] << "-" << atomType[i3] << "-" << atomType[i4] << endl; 
//													cout << atomResidue[i1] << ":" << residue[i1] << ":" << atomName[i1] << "-" << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl << endl;
//													cout << angle << " " << coupling_3J << endl << endl;
													
												}
											}	
										}
										
									}
								}
							}
						}

					}
				}
			}	
		}
	}
//	close files	
	co.close(); 
	coe.close();

	
	
	
	// NOE's	

	// all from less than max_distance
	
	int total_pairs=0;
	double temp_distance=0;
	int proton_pair_1[10000];
	int proton_pair_2[10000];
	double proton_pair_distance[10000];
	
	for(int i=0; i<10000; i++){
		proton_pair_1[i]=0;
		proton_pair_2[i]=0;
		proton_pair_distance[i]=0; 
	}

	
	// noe files
	
	string noe_output=out_directory;
	noe_output.append("/noe_output_");
	noe_output.append(pdb_file);
	noe_output.append(".txt");
	
	char *noeoutput=new char [noe_output.length()+1];
	strcpy(noeoutput, noe_output.c_str());

	ofstream noe(noeoutput);

	noe << "noe's satisfy the relationship for a single frame :" << endl << endl;
	noe << "r1^6 * noe1  -approximately equal to-  r2^6 * noe2" << endl;
	noe << "r1 and r2, noe1 and noe2, are distances and noe's of the 2 pairs of protons" << endl << endl;
	
	noe << "input and output files are : " << endl;
	noe << argv[1] << " " << argv[2] << endl;
	noe << noe_output << endl << endl;

	time (&rawtime);

	noe << "time of creation " << ctime (&rawtime) << endl;

	noe << "note : there are two lists in -this file-.  second list is friendly to copy and paste." << endl; 
	noe << "       there is a .csv file in the directory of the program output.  this is a -separate file-." << endl << endl << endl;


	
	// noe excel output

	string noe_output_excel=out_directory;
	noe_output_excel.append("/noe_output_");
	noe_output_excel.append(pdb_file);
	noe_output_excel.append(".csv");

	char *noeoutputexcel=new char [noe_output_excel.length()+1];
	strcpy(noeoutputexcel, noe_output_excel.c_str());

	ofstream noeoe;
	
	noeoe.open(noeoutputexcel);

	noeoe << "input and output files are : " << endl;
	noeoe << argv[1] << "," << argv[2] << endl;
	noeoe << noe_output_excel << endl << endl;
	noeoe << "time of creation " << ctime (&rawtime) << endl << endl;
	noeoe << "spin pair,proton numbers,ResName:ResNumber:Proton,ResName:ResNumber:ProtonName,r,r^6" << endl << endl;

	
	// protons
	
	for(int atom1=0; atom1<total_atoms; atom1++){
		if(atom_type[atom1].compare("H")==0){
			for(int atom2=atom1+1; atom2<total_atoms; atom2++){
				if(atom_type[atom2].compare("H")==0){
					temp_distance=sqrt(pow((atom_x[atom1]-atom_x[atom2]),2)+pow((atom_y[atom1]-atom_y[atom2]),2)+pow((atom_z[atom1]-atom_z[atom2]),2));
					if(temp_distance<max_distance){
						
						proton_pair_1[total_pairs]=atom1;
						proton_pair_2[total_pairs]=atom2;
						proton_pair_distance[total_pairs]=temp_distance;
						total_pairs++;
						
					}
				}
			}
		}

	}

	
	// no difference of <r> and (<1/r^6>)^(-1/6) if single frame is used

	// strength of noe is r^-6
	
	for(int i=0; i<total_pairs; i++){
		
		noe << "pair " << i << " : atom " << proton_pair_1[i] << " " << proton_pair_2[i] <<  endl;
		noe << atomResidue[proton_pair_1[i]] << ":" << residue[proton_pair_1[i]] << ":" << atomName[proton_pair_1[i]] << endl;	
		noe << atomResidue[proton_pair_2[i]] << ":" << residue[proton_pair_2[i]] << ":" << atomName[proton_pair_2[i]] << endl;	
		noe << proton_pair_distance[i] << endl;
		noe << endl;
		
	}

	noe << endl;

	// this jpart of the output is meant for loading into excel column format
	
	noe << "list of pairs of protons with inter-proton distance < " << max_distance << endl; 
	noe << endl;

	for(int i=0; i<total_pairs; i++){
		noe << i << " " << proton_pair_distance[i] << " " << pow(proton_pair_distance[i],6) << endl;
	}
	// close noe file
	noe.close();

	
	// excel output 
	
	for(int i=0; i<total_pairs; i++){
		noeoe << i << "," << proton_pair_1[i] << ":" << proton_pair_2[i] << "," << atomResidue[proton_pair_1[i]] << ":" << residue[proton_pair_1[i]] << ":" << atomName[proton_pair_1[i]] << "," << atomResidue[proton_pair_2[i]] << ":" << residue[proton_pair_2[i]] << ":" << atomName[proton_pair_2[i]] << "," << proton_pair_distance[i] << "," << pow(proton_pair_distance[i],6) << endl;
	}
	// close file
	noeoe.close();

	
	return 0; 
	
}


