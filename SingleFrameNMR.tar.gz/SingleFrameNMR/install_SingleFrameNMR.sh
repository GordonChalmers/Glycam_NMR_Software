
cd src
make
cp SingleFrameNMR ../bin/SingleFrameNMR

cd ..



