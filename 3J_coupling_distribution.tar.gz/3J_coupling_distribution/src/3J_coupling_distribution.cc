
// Gordon Chalmers

// The program will calculate all the 3J couplings of C-...-...-C, 
// C-...-...-H, H-...-...-C, H-...-...-H .

// The program takes uses a file called fileequation.txt which 
// has the coefficients of the Karpus equation.

// The program has several types of inputs 

//  calculate all 3J couplings

//  calculate all 3J couplings of a particular type, e.g. C-O-C-H

//  calculate all 3J couplings of a particular type, e.g. C-O-C-H, of particular residues

//  calculate all 3J couplings of a particular type, e.g. C-O-C-H, with coefficients

//  calculate all 3J couplings of a particular type, e.g. C-O-C-H, of particular residues and coefficients


#define GNUPLOT "gnuplot -persist"
#include <string>
#include <cstdlib>
#include <vector> 
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream> 
#include <sstream> 
using std::ios;
using namespace std;
#include <cstring>  
#include <math.h>
#include <list>

#include "glylib.h"

double string_to_double(const std::string& s)
{
	std::istringstream i(s);
	double x;
	if (!(i >> x))
	return 0;
	return x;
}

int string_to_int(const std::string& s)
{
	std::istringstream i(s);
	int x;
	if (!(i >> x))
	return 0;
	return x;
}

string int_to_string(int n)
{
	ostringstream strm;
	strm << n;
	return strm.str ();
}


int intfile=0;
int i,i2,i3,i4;  
double xcoordinate12,ycoordinate12,zcoordinate12;  
double xcoordinate34,ycoordinate34,zcoordinate34;     
double xcoordinate,ycoordinate,zcoordinate;
double xcross,ycross,zcross;
double ina, angleofatom;  
double angleindegrees;  
string * atomType=new string[10000];
int which_coordinate_file;  
string atomType1, atomType2, atomType3, atomType4;  
string text,type,text1,text2,text3,text4,text5,text6,text7;	
double coefficient[3];  
double * angle_bin=new double[360];
double x1,yy1,z1;
double x2,y2,z2;
double x3,y3,z3;
double x4,y4,z4;
int atom1,atom2,atom3,atom4;
double dotproduct;
int trajectory;
double coordinate;
double coupling_average;  
long int ad;
int sample_frequency;
int natom;
double coupling_standard_deviation;

// angle of the 1-2-3-4 atoms

// this uses fileequation.txt to calculate the 3J coupling 

// open trajectory - 1st atom

double trajectory_coordinate(char *file){
	
	std::ifstream fileofcoordinate;

	fileofcoordinate.open(file);   
	fileofcoordinate.seekg(0);
	getline(fileofcoordinate, text);
	ad = trajectory*(81 * ceil((double)natom * 3 / 10) - (10 - (3 * natom) % 10) * 8);
	fileofcoordinate.seekg(ad, ios_base::cur);

	for (int unused = 0; unused < ((double)(3 * atom1 - (3 * atom1) % 10) / 10); unused++){
		getline(fileofcoordinate, text);

	}
	getline(fileofcoordinate, text);

	coordinate = string_to_double(text.substr((size_t)((3 * atom1 * 8) % 80), 8));
	x1 = coordinate;

	if (((3 * atom1 * 8) % 80 + 16) != 88){
		coordinate = string_to_double(text.substr((size_t)abs((3 * atom1 * 8) % 80 + 8), 8));
		yy1 = coordinate;
		if (abs((3 * atom1* 8) % 80 + 24) <= 80){
			coordinate = string_to_double(text.substr((size_t)abs((3 * atom1 * 8) % 80 + 16), 8));
			z1 = coordinate;
		}
		else{
			getline(fileofcoordinate, text);
			coordinate = string_to_double(text.substr((size_t)(0), 8));
			z1 = coordinate;
		}
	}
	if (abs((3 * atom1 * 8) % 80 + 16) == 88){
		getline(fileofcoordinate, text);
		coordinate = string_to_double(text.substr((size_t)0, 8));
		yy1 = coordinate;
		coordinate = string_to_double(text.substr((size_t)8, 8));
		z1 = coordinate;
	}
	
	// 2nd atom coordinates						
	fileofcoordinate.seekg(0);
	getline(fileofcoordinate, text);
	ad = trajectory*(81 * ceil((double)natom * 3 / 10) - (10 - (3 * natom) % 10) * 8);
	fileofcoordinate.seekg(ad, ios_base::cur);

	for (int unused = 0; unused < ((double)(3 * atom2 - (3 * atom2) % 10) / 10); unused++){
		getline(fileofcoordinate, text);
	}
	getline(fileofcoordinate, text);

	coordinate = string_to_double(text.substr((size_t)((3 * atom2 * 8) % 80), 8));
	x2 = coordinate;
	
	if (((3 * atom2 * 8) % 80 + 16) != 88){
		coordinate = string_to_double(text.substr((size_t)abs((3 * atom2 * 8) % 80 + 8), 8));
		y2 = coordinate;

		if (abs((3 * atom2 * 8) % 80 + 24) <= 80){
			coordinate = string_to_double(text.substr((size_t)abs((3 * atom2 * 8) % 80 + 16), 8));
			z2 = coordinate;
		}
		else{
			getline(fileofcoordinate, text);
			coordinate = string_to_double(text.substr((size_t)(0), 8));
			z2 = coordinate;
		}
	}

	if (abs((3 * atom2 * 8) % 80 + 16) == 88){
		getline(fileofcoordinate, text);
		coordinate = string_to_double(text.substr((size_t)0, 8));
		y2 = coordinate;
		coordinate = string_to_double(text.substr((size_t)8, 8));
		z2 = coordinate;
	}
	
	// 3rd atom						

	fileofcoordinate.seekg(0);
	getline(fileofcoordinate, text);
	ad = trajectory*(81 * ceil((double)natom * 3 / 10) - (10 - (3 * natom) % 10) * 8);
	fileofcoordinate.seekg(ad, ios_base::cur);

	for (int unused = 0; unused < ((double)(3 * atom3 - (3 * atom3) % 10) / 10); unused++){
		getline(fileofcoordinate, text);
	}
	getline(fileofcoordinate, text);

	coordinate = string_to_double(text.substr((size_t)((3 * atom3 * 8) % 80), 8));
	x3 = coordinate;

	if (((3 * atom3 * 8) % 80 + 16) != 88){
		coordinate = string_to_double(text.substr((size_t)abs((3 * atom3 * 8) % 80 + 8), 8));
		y3 = coordinate;

		if (abs((3 * atom3 * 8) % 80 + 24) <= 80){
			coordinate = string_to_double(text.substr((size_t)abs((3 * atom3 * 8) % 80 + 16), 8));
			z3 = coordinate;
		}
		else{
			getline(fileofcoordinate, text);
			coordinate = string_to_double(text.substr((size_t)(0), 8));
			z3 = coordinate;
		}
	}

	if (abs((3 * atom3 * 8) % 80 + 16) == 88){
		getline(fileofcoordinate, text);
		coordinate = string_to_double(text.substr((size_t)0, 8));
		y3 = coordinate;
		coordinate = string_to_double(text.substr((size_t)8, 8));
		z3 = coordinate;
	}
	
	// 4th atom coordinates	  
	fileofcoordinate.seekg(0);
	getline(fileofcoordinate, text);
	ad = trajectory*(81 * ceil((double)natom * 3 / 10) - (10 - (3 * natom) % 10) * 8);
	fileofcoordinate.seekg(ad, ios_base::cur);

	for (int unused = 0; unused < ((double)(3 * atom4 - (3 * atom4) % 10) / 10); unused++){
		getline(fileofcoordinate, text);
	}
	getline(fileofcoordinate, text);

	coordinate = string_to_double(text.substr((size_t)((3 * atom4 * 8) % 80), 8));
	x4 = coordinate;

	if (((3 * atom4 * 8) % 80 + 16) != 88){
		coordinate = string_to_double(text.substr((size_t)abs((3 * atom4 * 8) % 80 + 8), 8));
		y4 = coordinate;

		if (abs((3 * atom4 * 8) % 80 + 24) <= 80){
			coordinate = string_to_double(text.substr((size_t)abs((3 * atom4 * 8) % 80 + 16), 8));
			z4 = coordinate;
		}
		else{
			getline(fileofcoordinate, text);
			coordinate = string_to_double(text.substr((size_t)(0), 8));
			z4 = coordinate;
		}
	}

	if (abs((3 * atom4 * 8) % 80 + 16) == 88){
		getline(fileofcoordinate, text);
		coordinate = string_to_double(text.substr((size_t)0, 8));
		y4 = coordinate;
		coordinate = string_to_double(text.substr((size_t)8, 8));
		z4 = coordinate;
	}
	fileofcoordinate.close();
	text.clear();
	return 0;
}

double spincoupling(string atom1, string atom2, string atom3, string atom4, double angle, string equationType, char * file){    

	ifstream fileofequationtype;
	fileofequationtype.open(file);
	fileofequationtype.seekg(0);

	if(fileofequationtype.good()==0){
		cout << "No file of equation coefficients is found." << endl;
		exit(1);
	}
	
	for(int i=0; i<100; i++){ 
		
		getline(fileofequationtype,type);
		getline(fileofequationtype,text1);
		getline(fileofequationtype,text2);
		getline(fileofequationtype,text3);
		getline(fileofequationtype,text4); 
		getline(fileofequationtype,text5);
		getline(fileofequationtype,text6);
		getline(fileofequationtype,text7);		
		
		if(type.compare(equationType)==0){
			if(atom1.compare(text1)==0){
				if(atom2.compare(text2)==0){  
					if(atom3.compare(text3)==0){
						if(atom4.compare(text4)==0){   

							coefficient[0]=string_to_double(text5); 
							coefficient[1]=string_to_double(text6); 
							coefficient[2]=string_to_double(text7); 

							type.clear();
							text1.clear(); text2.clear(); text3.clear(); text4.clear(); text5.clear(); text6.clear(); text7.clear();

							return coefficient[0]*cos(angle)*cos(angle)+coefficient[1]*cos(angle)+coefficient[2];
						}
					}
				}
			} 
			
		}
		
	}
	
	fileofequationtype.close();

	return 0;
}


void coordinate_atomType(int which_coordinate_file){ 

	xcoordinate12=(yy1-y2)*(z2-z3)-(z1-z2)*(y2-y3);
	ycoordinate12=(z1-z2)*(x2-x3)-(x1-x2)*(z2-z3);
	zcoordinate12=(x1-x2)*(y2-y3)-(yy1-y2)*(x2-x3);

	xcoordinate34=(y3-y4)*(z2-z3)-(z3-z4)*(y2-y3);
	ycoordinate34=(z3-z4)*(x2-x3)-(x3-x4)*(z2-z3);
	zcoordinate34=(x3-x4)*(y2-y3)-(y3-y4)*(x2-x3);

	ina = -(xcoordinate12*xcoordinate34+ycoordinate12*ycoordinate34+zcoordinate12*zcoordinate34);  
	ina = (double) ina / sqrt(xcoordinate12*xcoordinate12+ycoordinate12*ycoordinate12+zcoordinate12*zcoordinate12); 
	ina = (double) ina / sqrt(xcoordinate34*xcoordinate34+ycoordinate34*ycoordinate34+zcoordinate34*zcoordinate34);  	 

	xcoordinate=xcoordinate34-xcoordinate12;
	ycoordinate=ycoordinate34-ycoordinate12;
	zcoordinate=zcoordinate34-zcoordinate12;

	xcross=ycoordinate12*zcoordinate34-zcoordinate12*ycoordinate34;
	ycross=zcoordinate12*xcoordinate34-xcoordinate12*zcoordinate34;
	zcross=xcoordinate12*ycoordinate34-ycoordinate12*xcoordinate34;
	
	angleofatom=acos(ina);  
	dotproduct=xcoordinate*xcross+ycoordinate*ycross+zcoordinate*zcross;

	if(dotproduct<0){angleofatom=-angleofatom;}

	angleindegrees=(double) angleofatom*180/3.14159265;
}

int main(int argc, char *argv[]) { /* standard main function */


	if(argc!=7&&argc!=11&&argc!=15&&argc!=14&&argc!=18){
		cout << "Wrong number of inputs - should be 7,11,15,14,18 inputs.  See documentation." << endl;
		exit(1);
	}

	/* These variables are standard C variable types */
	int mi,ri,ai,bi; 	/* some counting indices */

	/* These are GLYLIB types */
	/*fileset OF;*/

	fileset IF; 

	/* Input and output file info
contains file name and pointer
this simplifies file error reporting */
	assembly A; 		/* an empty, unititialized assembly */
	molindex moli;		/* a molecule index ... m,r,a indices */
	molecule *mtmp;		/* Pointer to a molecule (for convenience) */
	residue *rtmp;		/* Pointer to a residue (for convenience) */
	atom *atmp, *a2tmp; 	/* Pointers to atom (for convenience) */
	/* It is always good to check the command line sanity */
	/* glylib contains many convenience functions, for example: */
	//if(argc<2){mywhineusage("Need input prmtop file name.");}

	/* copy the input file name to a convenient location */
	/* this is convenient, not efficient or necessary */
	IF.N = strdup(argv[1]); 	/* Copy name of input file */

	/* Now, load in the contents of the amber prmtop file */
	/* load_amber_prmtop requires the file not be open already */
	A = load_amber_prmtop(IF); 	/* initializes assembly, reads
						file, allocates memory,
						parses file, etc. */
	//	double atomMass[4000];
	string * atomName=new string[10000];
	string * atomType=new string[10000];
	//	int atomTypeNumber[4000];
	//	int atomNumber[4000];
	//	double atomCharge[4000];
	string * atomResidue=new string[10000];
	string * residue=new string[10000];

	// natom is # atoms
	natom = 0;
	if (A.nm < 1){ mywhine("No molecules found in prmtop file!"); }

	//	for (mi = 0; mi < A.nm; mi++) dprint_molecule(A.m[mi],100);
	//printf("nm is %d\n", A.nm);
	for (mi = 0; mi < A.nm; mi++){ /* for each molecule */
		mtmp = &A.m[mi][0]; /* set pointer for code-reading ease */
		//printf("\tnr is %d\n", A.m[mi][0].nr);
		for (ri = 0; ri < mtmp[0].nr; ri++){ /* each residue */
			//printf("\t\tri  is %d\n", ri);
			//printf("\t\tna from A is %d\n", A.m[mi][0].r[ri].na);
			//printf("\t\tna from mtmp is %d\n", mtmp[0].r[ri].na);
			rtmp = &mtmp[0].r[ri]; /* note ampersand*/

			//printf("\t\tna from rtmp is %d\n", rtmp[0].na);
			//printf("\t\tn from rtmp is %d\n", rtmp[0].n);
			
			for (ai = 0; ai < rtmp[0].na; ai++){ /* atom */
				atmp = &rtmp[0].a[ai];
				residue[natom] = int_to_string(rtmp[0].n);
				//residue[natom]=ri;
				//				atomMass[natom] = (atmp[0]).m;
				atomName[natom] = (atmp[0]).N;
				atomType[natom] = (atmp[0]).T[0];
				//				atomTypeNumber[natom] = (atmp[0]).t;
				//				atomNumber[natom] = (atmp[0]).n;
				//				atomCharge[natom] = (atmp[0]).ch[0];
				atomResidue[natom] = A.m[atmp[0].moli.m][0].r[atmp[0].moli.r].N;
				natom++;

			}
		}
	}
	
	int **adjacentAtom;
	adjacentAtom = new int* [natom];
	for (int i0=0; i0 < natom; i0++)
	adjacentAtom[i0] = new int[natom];

	for(mi=0;mi<A.nm;mi++){ /* for each molecule */
		mtmp=A.m[mi]; /* set pointer for code-reading ease */
		for(ri=0;ri < mtmp[0].nr;ri++){ /* each residue */
			rtmp = &mtmp[0].r[ri]; /* note ampersandÂ… */

			for(ai=0;ai < rtmp[0].na;ai++){ /* atom */ 
				atmp =&rtmp[0].a[ai]; 

				for(bi=0;bi<atmp[0].nmb;bi++){ /* for each bond */
					moli=atmp[0].mb[bi].t; /* for readability, copy the moli 
				of the target atom in the bond */
					a2tmp=&A.m[moli.m][0].r[moli.r].a[moli.a]; /* set a pointer
					to this bound atom */ 
					i=(atmp[0]).n;  
					i2=(a2tmp[0]).n;  
					adjacentAtom[i-1][i2-1]=2; 
				} 
			} /* close atom loop */
		} /* close residue loop */
	} /* close molecule loop */
	
	intfile=0;  

	ifstream fileofcoordinate;
	fileofcoordinate.open(argv[2]);   
	
	if(fileofcoordinate.good()==0){
		cout << "No trajectory file is found.  Please retry." << endl;
		exit(1);
	}
	getline(fileofcoordinate,text);  
	// intfile - how many frames in the file
	while(getline(fileofcoordinate,text)>0){     
		intfile++;
	}
	intfile=intfile/ceil((double) natom*3/10);

	fileofcoordinate.close();
	
//	if(argc==7){
//		if(intfile>500000){
//			cout << "There could be a problem with 6 inputs and more than 500,000 frames in this instance.  Frames are now the first 500,000.  Try using more inputs to limit the I/O." << endl;  
//			intfile=500000;
//		}
//	} 

	cout << "there are " << intfile << " frames and " << natom << " atoms" << endl;

	// sample out of frames
	
	sample_frequency=string_to_int(argv[5]);
	
	string test=argv[5];
	
	int not_number=2;
	
	for(int j=0; j<(signed) test.length() ; j=j+1){
		if (isdigit(test[j])==0) not_number=0;
	}
	
	if(not_number==0){
		cout << "Sample frequency is not an integer." << endl;
		exit(1);
	}
	
	if(sample_frequency==0){
		cout << "Sample frequency 0 is not allowed." << endl;
		exit(1);
	}
	
	// output files 

	string CC=argv[3];
	CC.append("/fileCC.txt");
	char *CCfile=new char [CC.length()+1];
	strcpy(CCfile, CC.c_str());

	ofstream fileCC(CCfile);
	fileCC << "Number of atoms : " << natom << endl;  
	fileCC << endl;

	string HH=argv[3];
	HH.append("/fileHH.txt");
	char *HHfile=new char [HH.length()+1];
	strcpy(HHfile, HH.c_str());

	ofstream fileHH(HHfile);
	fileHH << "Number of atoms : " << natom << endl;  
	fileHH << endl;

	string CH=argv[3];
	CH.append("/fileCH.txt");
	char *CHfile=new char [CH.length()+1];
	strcpy(CHfile,CH.c_str());

	ofstream fileCH(CHfile);
	fileCH << "Number of atoms : " << natom << endl;  
	fileCH << endl;

	string FILE=argv[3];
	FILE.append("/file.txt");
	char *FILENON=new char [FILE.length()+1];
	strcpy(FILENON,FILE.c_str());

	ofstream file(FILENON);
	file << "Number of atoms " << natom << endl;  
	file << endl;

	// i,i2,i3,i4 are the atoms  

	for(i=0; i<natom; i++){   
		for(i2=0; i2<natom; i2++){ 
			for(i3=0; i3<natom; i3++){ 
				for(i4=0; i4<natom; i4++){ 

					atom1=i;
					atom2=i2;
					atom3=i3;
					atom4=i4;

					// check if the atoms are connected

					if(adjacentAtom[i][i2]==2&&i!=i3&&i!=i4&&i2!=i3&&i2!=i4){
						if(adjacentAtom[i2][i3]==2&&i3!=i&&i4!=i3&&i2!=i&&i2!=i4){
							if(adjacentAtom[i3][i4]==2&&i4!=i2&&i4!=i&&i3!=i&&i3!=i2){ 

								if(i<i4){

									char *atomName1 = new char[atomName[i].length() + 1];
									char *atomName2 = new char[atomName[i2].length() + 1];
									char *atomName3 = new char[atomName[i3].length() + 1];
									char *atomName4 = new char[atomName[i4].length() + 1];
									char *atomResidue1 = new char[atomResidue[i].length() + 1];
									char *atomResidue2 = new char[atomResidue[i2].length() + 1];
									char *atomResidue3 = new char[atomResidue[i3].length() + 1];
									char *atomResidue4 = new char[atomResidue[i4].length() + 1];
									char *residue1 = new char[residue[i].length() + 1];
									char *residue2 = new char[residue[i2].length() + 1];
									char *residue3 = new char[residue[i3].length() + 1];
									char *residue4 = new char[residue[i4].length() + 1];

									strcpy(atomResidue1, atomResidue[i].c_str());
									strcpy(atomResidue2, atomResidue[i2].c_str());
									strcpy(atomResidue3, atomResidue[i3].c_str());
									strcpy(atomResidue4, atomResidue[i4].c_str());
									strcpy(atomName1, atomName[i].c_str());
									strcpy(atomName2, atomName[i2].c_str());
									strcpy(atomName3, atomName[i3].c_str());
									strcpy(atomName4, atomName[i4].c_str());
									strcpy(residue1, residue[i].c_str());
									strcpy(residue2, residue[i2].c_str());
									strcpy(residue3, residue[i3].c_str());
									strcpy(residue4, residue[i4].c_str());

									// user knows which calculation
									
									atomType1=atomType[i]; 
									atomType2=atomType[i2]; 
									atomType3=atomType[i3]; 
									atomType4=atomType[i4];  	 

									coupling_average=0; 
									
									string angle_distribution=argv[3];									
									angle_distribution.append("/angle_distribution_");
									angle_distribution.append(atomResidue[i]);
									angle_distribution.append("_");
									angle_distribution.append(residue[i]);
									angle_distribution.append("_");
									angle_distribution.append(atomName[i]);
									angle_distribution.append(":");
									angle_distribution.append(atomResidue[i2]);
									angle_distribution.append("_");
									angle_distribution.append(residue[i2]);
									angle_distribution.append("_");
									angle_distribution.append(atomName[i2]);
									angle_distribution.append(":");
									angle_distribution.append(atomResidue[i3]);
									angle_distribution.append("_");
									angle_distribution.append(residue[i3]);
									angle_distribution.append("_");
									angle_distribution.append(atomName[i3]);
									angle_distribution.append(":");
									angle_distribution.append(atomResidue[i4]);
									angle_distribution.append("_");
									angle_distribution.append(residue[i4]);
									angle_distribution.append("_");
									angle_distribution.append(atomName[i4]);
									angle_distribution.append(".txt");

									char *angle_file=new char [angle_distribution.length()+1];
									strcpy(angle_file,angle_distribution.c_str());
									
									if(argc==7){ 						
										
										if(atomType1.compare("C")==0){ 
											if(atomType4.compare("C")==0){
												
												for(int j=0; j<360; j=j+1){													
													angle_bin[j]=0;
												}
												
												trajectory=0;
												trajectory_coordinate(argv[2]);

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.00001){ 
													cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
													cout << "not in fileequation" << endl;
													cout << endl;
												}

												coupling_average=0;

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

													fileCC << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
													fileCC << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	
														coordinate_atomType(which_coordinate_file);  

														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													coupling_standard_deviation=0;	
													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													fileCC << coupling_average << " " << coupling_standard_deviation << endl << endl;  

													cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													cout << coupling_average << " " << coupling_standard_deviation << endl;
													cout << endl;

													ofstream angletext(angle_file);
													
													for(int j=0; j<=360; j=j+1){
														angletext << angle_bin[j] << endl;
													}
													
													angletext.close();
													
													//	  FILE * gp = popen(GNUPLOT, "w");
													//	  if (gp == NULL){
													//	     return 0;
													//	  }
													
													//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

													//	 fclose(gp);

												}
												
											}     
										}

										if(atomType1.compare("H")==0){ 
											if(atomType4.compare("H")==0){
												
												for(int j=0; j<=360; j=j+1){
													angle_bin[j]=0;
												}
												
												trajectory=0;
												trajectory_coordinate(argv[2]);

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.00001){ 
													cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
													cout << "not in fileequation" << endl;
													cout << endl;
												}

												coupling_average=0;
												
												coupling_standard_deviation=0;

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

													fileHH << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
													fileHH << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
																
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													fileHH << coupling_average << " " << coupling_standard_deviation << endl << endl;  

													cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													cout << coupling_average << " " << coupling_standard_deviation << endl;
													cout << endl;

													ofstream angletext(angle_file);
													for(int j=0; j<=360; j=j+1){
														angletext << angle_bin[j] << endl;
													}
													angletext.close();
													
													//	  FILE * gp = popen(GNUPLOT, "w");
													//	  if (gp == NULL){
													//	     return 0;
													//	  }
													
													//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

													//	 fclose(gp);
													
												}	
												
											}  
										}
										
										if(atomType1.compare("C")==0){ 
											if(atomType4.compare("H")==0){

												for(int j=0; j<=360; j=j+1){
													angle_bin[j]=0;
												}

												trajectory=0;
												trajectory_coordinate(argv[2]);

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.00001){ 
													cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
													cout << "not in fileequation" << endl;
													cout << endl;
												}

												coupling_average=0;

												coupling_standard_deviation=0;
												
												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

													fileCH << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
													fileCH << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	
													
													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													fileCH << coupling_average << " " << coupling_standard_deviation << endl << endl;  

													cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													cout << coupling_average << " " << coupling_standard_deviation << endl;
													cout << endl;

													ofstream angletext(angle_file);
													for(int j=0; j<=360; j=j+1){
														angletext << angle_bin[j] << endl;
													}
													angletext.close();
													
													//	  FILE * gp = popen(GNUPLOT, "w");
													//	  if (gp == NULL){
													//	     return 0;
													//	  }
													
													//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

													//	 fclose(gp);
													
												}
												
											}
										}
										
										if(atomType1.compare("H")==0){ 
											if(atomType4.compare("C")==0){
												
												for(int j=0; j<=360; j=j+1){
													angle_bin[j]=0;
												}
												
												trajectory=0;
												trajectory_coordinate(argv[2]);

												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.00001){ 
													cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
													cout << "not in fileequation" << endl;
													cout << endl;
												}

												coupling_average=0;

												coupling_standard_deviation=0;
												
												if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

													fileCH << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
													fileCH << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 

														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													fileCH << coupling_average << " " << coupling_standard_deviation << endl << endl;  

													cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
													cout << coupling_average << " " << coupling_standard_deviation << endl;
													cout << endl;

													ofstream angletext(angle_file);
													for(int j=0; j<=360; j=j+1){
														angletext << angle_bin[j] << endl;
													}
													angletext.close();
													
													//	  FILE * gp = popen(GNUPLOT, "w");
													//	  if (gp == NULL){
													//	     return 0;
													//	  }
													
													//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

													//	 fclose(gp);
													
												}											
												
											}    
										}
									} 


									// this uses all the atoms, e.g. C-C-C-C as input

									if(argc==11){ 
										
										if(atomType1.compare(argv[7])==0){ 
											if(atomType2.compare(argv[8])==0){
												if(atomType3.compare(argv[9])==0){ 
													if(atomType4.compare(argv[10])==0){  

														for(int j=0; j<=360; j=j+1){		
															angle_bin[j]=0;
														}
														
														trajectory=0;
														trajectory_coordinate(argv[2]);

														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.0000100){ 
															cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
															cout << "not in fileequation" << endl;
															cout << endl;
														}

														coupling_average=0;
                                                                                                                                               
                                                                                                                coupling_standard_deviation=0;
																		
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

															file << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
															file << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
														
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 

														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													file << coupling_average << " " << coupling_standard_deviation << endl << endl;  

															cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
															cout << coupling_average << " " << coupling_standard_deviation << endl;
															cout << endl;

															ofstream angletext(angle_file);
															for(int j=0; j<=360; j=j+1){
																angletext << angle_bin[j] << endl;
															}
															angletext.close();
															
															//	  FILE * gp = popen(GNUPLOT, "w");
															//	  if (gp == NULL){
															//	     return 0;
															//	  }
															
															//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

															//	 fclose(gp);
															
														}
													}   
												}
											} 
										}      
									}
									
									// this uses all the atoms, e.g. C-C-C-C, and residues as input

									if(argc==15){ 
										
										if(atomType1.compare(argv[7])==0){ 
											if(atomType2.compare(argv[8])==0){
												if(atomType3.compare(argv[9])==0){ 
													if(atomType4.compare(argv[10])==0){  

														if(residue[i].compare(argv[11])==0){ 
															if(residue[i2].compare(argv[12])==0){
																if(residue[i3].compare(argv[13])==0){ 
																	if(residue[i4].compare(argv[14])==0){  
																		
																		for(int j=0; j<=360; j=j+1){		
																			angle_bin[j]=0;
																		}
																		
																		trajectory=0;
																		trajectory_coordinate(argv[2]);

																		if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])<.0000100){ 
																			cout << atomType1 << " " << atomType2 << " " << atomType3 << " " << atomType4 << endl;
																			cout << "not in fileequation" << endl;
																			cout << endl;
																		}

																		coupling_average=0;

                                                                                                                                                coupling_standard_deviation=0; 																	
																		if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 

																			file << i << " " << i2 << " " << i3 << " " << i4 << " : " << atomType1 << "-" << atomType2 << "-" << atomType3 << "-" << atomType4 << endl; 
																			file << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
																			
																			
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 

														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coupling_average+=spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6]);
														}
													}	

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
														trajectory=which_coordinate_file;
														trajectory_coordinate(argv[2]);	 														
														coordinate_atomType(which_coordinate_file);  
														
														if(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])>0){ 
															coupling_standard_deviation+=(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average)*(spincoupling(atomType1, atomType2, atomType3, atomType4,angleofatom,argv[4],argv[6])-coupling_average);
														}
													}	
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													file << coupling_average << " " << coupling_standard_deviation << endl << endl;  

																			cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
																			cout << coupling_average << endl;
																			cout << endl;
																			
																			ofstream angletext(angle_file);
																			for(int j=0; j<=360; j=j+1){
																				angletext << angle_bin[j] << endl;
																			}
																			angletext.close();
																			
																			//	  FILE * gp = popen(GNUPLOT, "w");
																			//	  if (gp == NULL){
																			//	     return 0;
																			//	  }
																			
																			//	 fprintf(gp, " set terminal jpeg \n unset key \n set output '%s/%s_%s_%s-%s_%s_%s_%s_%s_%s-%s_%s_%s_angle_distribution.jpeg' \n set xlabel 'angle (in degrees)' \n set title 'angle distribution - atoms %s:%s:%s  %s:%s:%s %s:%s:%s  %s:%s:%s\n plot '%s' \n ", argv[3], atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2, atomResidue3, residue3, atomName3,atomResidue4, residue4, atomName4,  atomResidue1, residue1, atomName1, atomResidue2, residue2, atomName2,atomResidue3, residue3, atomName3, atomResidue4, residue4, atomName4,  angle_file);

																			//	 fclose(gp);
																		}

																	}   
																}
															} 
														}      
													}   
												}
											} 
										}      
									}
									
									// this uses all the atoms, e.g. C-C-C-C, with coefficients also

									if(argc==14){ 

										double coeff[3];  
										double coupling_average=0;
										for(int j=0; j<=360; j=j+1){
											angle_bin[j]=0;
										}
										
										trajectory=0;
										trajectory_coordinate(argv[2]);
										
										if(atomType1.compare(argv[7])==0){ 
											if(atomType2.compare(argv[8])==0){
												if(atomType3.compare(argv[9])==0){ 
													if(atomType4.compare(argv[10])==0){  

														coeff[0]=string_to_double(argv[11]);  
														coeff[1]=string_to_double(argv[12]); 
														coeff[2]=string_to_double(argv[13]);  
														
														coupling_average=0;

                                                                                                                coupling_standard_deviation=0;
																		
														
														for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
															
															trajectory=which_coordinate_file;
															trajectory_coordinate(argv[2]);	 
															coordinate_atomType(which_coordinate_file);  
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coordinate_atomType(which_coordinate_file); 

															if((coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2])>.01){  
																coupling_average+=coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2];
															} 
														} 

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
															
															trajectory=which_coordinate_file;
															trajectory_coordinate(argv[2]);	 
															coordinate_atomType(which_coordinate_file);  
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coordinate_atomType(which_coordinate_file); 

															if((coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2])>.01){  
										coupling_standard_deviation+=(coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2]-coupling_average)*(coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2]-coupling_average);

															} 
														} 
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													file << coupling_average << " " << coupling_standard_deviation << endl << endl;  

														cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
														cout << coupling_average << endl;
														cout << endl;
														
														ofstream angletext(angle_file);
														for(int j=0; j<=360; j=j+1){
															angletext << angle_bin[j] << endl;
														}
														angletext.close();
														
													}	 
												}
											}
										} 
									}
									
									// this uses all the atoms, e.g. C-C-C-C, with residues and coefficients also
									
									if(argc==18){ 

										double coeff[3];  
										double coupling_average=0;
										for(int j=0; j<=360; j=j+1){
											angle_bin[j]=0;
										}
										
										trajectory=0;
										trajectory_coordinate(argv[2]);
										
										if(atomType1.compare(argv[7])==0){ 
											if(atomType2.compare(argv[8])==0){
												if(atomType3.compare(argv[9])==0){ 
													if(atomType4.compare(argv[10])==0){  

														if(residue[i].compare(argv[11])==0){ 
															if(residue[i2].compare(argv[12])==0){
																if(residue[i3].compare(argv[13])==0){ 
																	if(residue[i4].compare(argv[14])==0){  
																		
																		coeff[0]=string_to_double(argv[15]);  
																		coeff[1]=string_to_double(argv[16]); 
																		coeff[2]=string_to_double(argv[17]);  
																		
																		coupling_average=0;

                                                                                                                                                coupling_standard_deviation=0;
																		
																		for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
															
															trajectory=which_coordinate_file;
															trajectory_coordinate(argv[2]);	 
															coordinate_atomType(which_coordinate_file);  
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coordinate_atomType(which_coordinate_file); 

															if((coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2])>.01){  
																coupling_average+=coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2];
															} 
														} 

													
													coupling_average=(double) coupling_average/intfile*sample_frequency;

													
													for(int which_coordinate_file=0; which_coordinate_file<intfile; which_coordinate_file=which_coordinate_file+sample_frequency){ 
															
															trajectory=which_coordinate_file;
															trajectory_coordinate(argv[2]);	 
															coordinate_atomType(which_coordinate_file);  
															angle_bin[(int) round(angleindegrees)+180]=angle_bin[(int) round(angleindegrees)+180]+1;
															coordinate_atomType(which_coordinate_file); 

															if((coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2])>.00001){  
										coupling_standard_deviation+=(coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2]-coupling_average)*(coeff[0]*cos(angleofatom)*cos(angleofatom)+coeff[1]*cos(angleofatom)+coeff[2]-coupling_average);

															} 
														} 
													
													coupling_standard_deviation=sqrt((double) coupling_standard_deviation/intfile*sample_frequency);


													file << coupling_average << " " << coupling_standard_deviation << endl << endl;  

																		cout << atomResidue[i] << ":" << residue[i] << ":" << atomName[i] << " " << atomResidue[i2] << ":" << residue[i2] << ":" << atomName[i2] << " " << atomResidue[i3] << ":" << residue[i3] << ":" << atomName[i3] << " " << atomResidue[i4] << ":" << residue[i4] << ":"<< atomName[i4] << endl;
																		cout << coupling_average << endl;
																		cout << endl;
																		
																		ofstream angletext(angle_file);
																		for(int j=0; j<=360; j=j+1){
																			angletext << angle_bin[j] << endl;
																		}
																		angletext.close();
																	}	 
																}
															}
														} 
													}	 
												}
											}
										} 
									}

								}
							}
						}
					}
				}
			}
		}
	}


	fileCC.close();  
	fileCH.close();
	fileHH.close();  
	file.close(); 

	return 0; /* indicate successful completion */

}


