
cd ../..
rm -r 3J_coupling_distribution