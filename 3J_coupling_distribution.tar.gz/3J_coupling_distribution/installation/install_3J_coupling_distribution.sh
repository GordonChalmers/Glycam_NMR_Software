
cd ../src
make
cp 3J_coupling_distribution ../bin/3J_coupling_distribution

cd ../arixtra_1C4_example

chmod +x bash_arixtra_1C4.in

chmod +x bash_arixtra_1C4_COCH.in

chmod +x bash_arixtra_1C4_COCH_2233.in

chmod +x bash_arixtra_1C4_COCH_coeff.in

chmod +x bash_arixtra_1C4_COCH_2233_coeff.in

cd ../..


